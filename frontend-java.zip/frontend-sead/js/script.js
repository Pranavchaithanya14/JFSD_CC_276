let token = null;
let currentUser = null;
let currentApplicationId = null;
let applicationData = null;
function showRegister() {
  console.log('register');
  document.getElementById('auth-section').style.display = 'none';
  document.getElementById('register-section').style.display = 'block';
  register();
}

function showLogin() {
  document.getElementById('register-section').style.display = 'none';
  document.getElementById('auth-section').style.display = 'block';
}

async function register() {
  const username = document.getElementById('reg-username').value;
  const email = document.getElementById('reg-email').value;
  const password = document.getElementById('reg-password').value;
  try {
  const response = await fetch('http://localhost:7500/api/users/register', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ username, email, password }),
  });
  const text = await response.text();
    const data = text ? JSON.parse(text) : { message: 'No response from server' };
    if (response.ok) {
      alert('Registration successful! Please log in.');
      showLogin();
    } else {
      alert(data.message || 'Registration failed');
    }
  } catch (error) {
    alert('Error: ' + error.message);
  }
}

async function login() {
  const username = document.getElementById('login-username').value;
  const password = document.getElementById('login-password').value;
  try {
  const response = await fetch('http://localhost:7500/api/users/login', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ username, password }),
  });
  const text = await response.text();
  const data = text ? JSON.parse(text) : { message: 'No response from server' };
  if (response.ok) {
      token = data.token;
      currentUser = username;
      localStorage.removeItem('draft');
      document.getElementById('auth-section').style.display = 'none';
      document.getElementById('application-section').style.display = 'block';
      loadDraft();
  } else {
    alert(data.message || 'Login failed');
  }
} catch (error) {
  alert('Error: ' + error.message);
}
}

function addMoreDocs() {
  const docUploads = document.getElementById('docUploads');
  const newDoc = document.createElement('div');
  newDoc.innerHTML = `
    <select name="docType" required>
      <option value="">Select Document Type</option>
      <option value="Aadhaar">Aadhaar</option>
      <option value="Birth Certificate">Birth Certificate</option>
      <option value="Photo">Passport Photo</option>
    </select>
    <input type="file" name="documents" accept=".pdf,.jpg,.png" required><br>
  `;
  docUploads.appendChild(newDoc);
}

async function submitApplication() {
  const fullName = document.getElementById('fullName').value;
  const dob = document.getElementById('dob').value;
  const address = document.getElementById('address').value;
  const nationality = document.getElementById('nationality').value;
  const gender = document.getElementById('gender').value;
  const phone = document.getElementById('phone').value;
  const fatherName = document.getElementById('fatherName').value;
  const motherName = document.getElementById('motherName').value;
  const maritalStatus = document.getElementById('maritalStatus').value;
  const docTypes = Array.from(document.getElementsByName('docType')).map(select => select.value);
  const docFiles = Array.from(document.getElementsByName('documents')).map(input => input.files[0]);
  const appointmentDate = document.getElementById('appointmentDate').value;
  // Document Validation
  for (let file of docFiles) {
    if (!file) {
      alert('Please upload all required documents');
      return;
    }
    if (file.size > 5 * 1024 * 1024) { // 5MB limit
      alert('File ' + file.name + ' is too large (max 5MB)');
      return;
    }
    if (!['application/pdf', 'image/jpeg', 'image/png'].includes(file.type)) {
      alert('File ' + file.name + ' must be PDF, JPG, or PNG');
      return;
    }
  }
  const formData = new FormData();
  formData.append('fullName', fullName);
  formData.append('dob', dob);
  formData.append('address', address);
  formData.append('nationality', nationality);
  formData.append('gender', gender);
  formData.append('phone', phone);
  formData.append('fatherName', fatherName);
  formData.append('motherName', motherName);
  formData.append('maritalStatus', maritalStatus);
  formData.append('appointmentDate', appointmentDate);
  docFiles.forEach((file, index) => {
    formData.append('documents', file);
    formData.append('docTypes', docTypes[index]);
  });

  applicationData = { fullName, dob, address, nationality, gender, phone, fatherName, motherName, maritalStatus, appointmentDate };

  try {
    const response = await fetch('http://localhost:7500/api/applications/submit', {
      method: 'POST',
      headers: { 'Authorization': `Bearer ${token}` },
      body: formData,
    });
    const text = await response.text();
    const data = text ? JSON.parse(text) : { message: 'No response from server' };
    if (response.ok) {
      currentApplicationId = data.applicationId;
      document.getElementById('app-id').textContent = currentApplicationId;
      document.getElementById('submission-result').style.display = 'block';
      document.getElementById('application-form').reset();
      localStorage.removeItem('draft');
      sendEmailNotification(currentApplicationId);
    } else {
      alert(data.message || 'Submission failed');
    }
  } catch (error) {
    alert('Error: ' + error.message);
  }
}
function downloadReceipt() {
  const { jsPDF } = window.jspdf;
  const doc = new jsPDF();
  doc.text('Passport Application Receipt', 10, 10);
  doc.text(`Application ID: ${currentApplicationId}`, 10, 20);
  doc.text(`Full Name: ${applicationData.fullName}`, 10, 30);
  doc.text(`Date of Birth: ${applicationData.dob}`, 10, 40);
  doc.text(`Address: ${applicationData.address}`, 10, 50);
  doc.text(`Nationality: ${applicationData.nationality}`, 10, 60);
  doc.text(`Gender: ${applicationData.gender}`, 10, 70);
  doc.text(`Phone: ${applicationData.phone}`, 10, 80);
  doc.text(`Father's Name: ${applicationData.fatherName}`, 10, 90);
  doc.text(`Mother's Name: ${applicationData.motherName}`, 10, 100);
  doc.text(`Marital Status: ${applicationData.maritalStatus}`, 10, 110);
  doc.text(`Appointment Date: ${applicationData.appointmentDate}`, 10, 120);
  doc.save(`passport_receipt_${currentApplicationId}.pdf`);
}

      
function showStatusPage() {
  document.getElementById('application-section').style.display = 'none';
  document.getElementById('status-section').style.display = 'block';
}

function showApplicationPage() {
  document.getElementById('status-section').style.display = 'none';
  document.getElementById('application-section').style.display = 'block';
  document.getElementById('submission-result').style.display = 'none';
}
async function trackStatus() {
  const applicationId = document.getElementById('track-id').value.trim();
  if (!applicationId) {
    document.getElementById('status-result').innerHTML = '<p>Please enter an Application ID.</p>';
    return;
  }
  try {
  const response = await fetch('http://localhost:7500/api/applications/status', {
    headers: { 'Authorization': `Bearer ${token}` },
  });
  const text = await response.text();
  const data = text ? JSON.parse(text) : { message: 'No response from server' };
  const resultDiv = document.getElementById('status-result');
  if (response.ok) {
    let statusText = data.status.charAt(0).toUpperCase() + data.status.slice(1);
    if (data.status === 'approved') statusText = 'Accepted'; // Replace 'approved' with 'accepted'
    resultDiv.innerHTML = `
      <p class="${data.status}">Application ID: ${data._id} - Status: ${statusText}</p>
    `;
  } else {
    resultDiv.innerHTML = `<p>Error: ${data.message}</p>`;
  }
} catch (error) {
  document.getElementById('status-result').innerHTML = `<p>Error: ${error.message}</p>`;
}
}
function logout() {
  token = null;
  currentUser = null;
  currentApplicationId = null;
  applicationData = null;
  localStorage.removeItem('draft');
  document.getElementById('application-section').style.display = 'none';
  document.getElementById('status-section').style.display = 'none';
  document.getElementById('auth-section').style.display = 'block';
}
// Real-Time Form Validation
document.getElementById('application-form').addEventListener('input', () => {
  const error = document.getElementById('error');
  if (!document.getElementById('fullName').value) error.textContent = 'Full Name is required';
  else if (!document.getElementById('phone').value.match(/^\d{10}$/)) error.textContent = 'Phone must be 10 digits';
  else error.textContent = '';
});

// Auto-Save Draft
function saveDraft() {
  if (!currentUser) return;
  const formData = {
    fullName: document.getElementById('fullName').value,
    dob: document.getElementById('dob').value,
    address: document.getElementById('address').value,
    nationality: document.getElementById('nationality').value,
    gender: document.getElementById('gender').value,
    phone: document.getElementById('phone').value,
    fatherName: document.getElementById('fatherName').value,
    motherName: document.getElementById('motherName').value,
    maritalStatus: document.getElementById('maritalStatus').value,
    appointmentDate: document.getElementById('appointmentDate').value,
  };
  localStorage.setItem('draft', JSON.stringify(formData));
}

function loadDraft() {
  if (!currentUser) return;
  const draft = JSON.parse(localStorage.getItem(`draft_${currentUser}`));
  if (draft) {
    document.getElementById('fullName').value = draft.fullName || '';
    document.getElementById('dob').value = draft.dob || '';
    document.getElementById('address').value = draft.address || '';
    document.getElementById('nationality').value = draft.nationality || '';
    document.getElementById('gender').value = draft.gender || '';
    document.getElementById('phone').value = draft.phone || '';
    document.getElementById('fatherName').value = draft.fatherName || '';
    document.getElementById('motherName').value = draft.motherName || '';
    document.getElementById('maritalStatus').value = draft.maritalStatus || '';
    document.getElementById('appointmentDate').value = draft.appointmentDate || '';
  } else {
    // Clear form for new user
    document.getElementById('application-form').reset();
  }
}

setInterval(saveDraft, 30000); // Auto-save every 30 seconds

window.onload = () => {
  if (document.getElementById('application-section').style.display === 'block') {
    loadDraft();
  }
};