// Retrieve selected bus information from local storage
const selectedBus = JSON.parse(localStorage.getItem('selectedBus'));

if (selectedBus) {
    const { boarding, dropping, time, cost, available, seats } = selectedBus;
    document.getElementById('selectedBusInfo').innerHTML = `
        <p><strong>Boarding Point:</strong> ${boarding}</p>
        <p><strong>Dropping Point:</strong> ${dropping}</p>
        <p><strong>Time:</strong> ${time}</p>
        <p><strong>Cost:</strong> $${cost} per seat</p>
        <p><strong>Number of Seats:</strong> ${seats}</p>
        <p><strong>Total Cost:</strong> $${cost * seats}</p>
    `;
} else {
    document.getElementById('selectedBusInfo').innerHTML = '<p>No bus selected. Please go back to the dashboard.</p>';
}

// Payment method handling
document.getElementById('phonePe').addEventListener('click', function() {
    alert('Payment via PhonePe is selected.');
    // Here you can add further logic for processing the payment
});

document.getElementById('googlePay').addEventListener('click', function() {
    alert('Payment via Google Pay is selected.');
    // Here you can add further logic for processing the payment
});

document.getElementById('paytm').addEventListener('click', function() {
    alert('Payment via Paytm is selected.');
    // Here you can add further logic for processing the payment
});

document.getElementById('netBanking').addEventListener('click', function() {
    alert('Payment via Net Banking is selected.');
    // Here you can add further logic for processing the payment
});

// Logout functionality
document.getElementById('logout').addEventListener('click', function() {
    localStorage.removeItem('loggedInUser  '); // Remove username from local storage
    window.location.href = 'index.html'; // Redirect to login page
});

// On page load, display the username
document.addEventListener('DOMContentLoaded', function() {
    const loggedInUser  = localStorage.getItem('loggedInUser  ');
    if (loggedInUser ) {
        document.getElementById('usernameDisplay').innerText = loggedInUser ; // Display username
    }
});