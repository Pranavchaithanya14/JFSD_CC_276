// Sample user data for login
const users = [
    { username: 'user1', password: 'pass1' },
    { username: 'user2', password: 'pass2' }
];

// Login form handling
document.getElementById('loginForm')?.addEventListener('submit', function(event) {
    event.preventDefault();
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;
    const user = users.find(u => u.username === username && u.password === password);

    if (user) {
        // Store the username in local storage
        localStorage.setItem('loggedInUser ', username);
        // Redirect to dashboard
        window.location.href = 'dashboard.html';
    } else {
        document.getElementById('error').innerText = 'Invalid username or password';
    }
});

// On dashboard load, display the username
document.addEventListener('DOMContentLoaded', function() {
    const loggedInUser  = localStorage.getItem('loggedInUser ');
    if (loggedInUser ) {
        document.getElementById('usernameDisplay').innerText = loggedInUser ; // Display username
    }
});

// Sample bus data
const busData = [
    { boarding: 'A', dropping: 'B', time: '10:00 AM', date: '2023-10-01', cost: 100, availableTickets: 5 },
    { boarding: 'B', dropping: 'C', time: '12:00 PM', date: '2023-10-01', cost: 150, availableTickets: 3 },
    { boarding: 'A', dropping: 'C', time: '2:00 PM', date: '2023-10-02', cost: 200, availableTickets: 2 },
    { boarding: 'C', dropping: 'A', time: '4:00 PM', date: '2023-10-02', cost: 120, availableTickets: 0 }
];

// Search functionality
document.getElementById('searchButton')?.addEventListener('click', function() {
    const boardingInput = document.getElementById('boardingPoint').value.toLowerCase();
    const droppingInput = document.getElementById('droppingPoint').value.toLowerCase();
    const dateInput = document.getElementById('date').value;

    const filteredBuses = busData.filter(bus => {
        const boardingMatch = bus.boarding.toLowerCase() === boardingInput;
        const droppingMatch = bus.dropping.toLowerCase() === droppingInput;
        const dateMatch = dateInput ? bus.date === dateInput : true; // If no date is selected, match all dates
        return boardingMatch && droppingMatch && dateMatch;
    });

    const busInfo = filteredBuses.length > 0 ? filteredBuses.map(bus => `
        <div class="bus-item">
            <p>Boarding: ${bus.boarding}</p>
            <p>Dropping: ${bus.dropping}</p>
            <p>Time: ${bus.time}</p>
            <p>Date: ${bus.date}</p>
            <p>Cost: $${bus.cost}</p>
            <p>Available Tickets: ${bus.availableTickets}</p>
            <input type="number" class="seatsInput" placeholder="Seats" min="1" max="${bus.availableTickets}" value="1">
            <button class="selectBus" data-boarding="${bus.boarding}" data-dropping="${bus.dropping}" data-time="${bus.time}" data-cost="${bus.cost}" data-available="${bus.availableTickets}">Select</button>
        </div>
    `).join('') : '<p>No buses found for the selected criteria.</p>';

    document.getElementById('bus-info').innerHTML = busInfo;

    // Add event listeners to the select buttons
    document.querySelectorAll('.selectBus').forEach(button => {
        button.addEventListener('click', function() {
            const boarding = this.getAttribute('data-boarding');
            const dropping = this.getAttribute('data-dropping');
            const time = this.getAttribute('data-time');
            const cost = this.getAttribute('data-cost');
            const available = this.getAttribute('data-available');
            const seats = this.previousElementSibling.value; // Get the number of seats from the input

            // Store selected bus information in local storage
            localStorage.setItem('selectedBus', JSON.stringify({
                boarding,
                dropping,
                time,
                cost,
                available,
                seats // Store the number of seats
            }));

            // Redirect to payment options page
            window.location.href = 'payment.html';
        });
    });
});

// Logout functionality
document.getElementById('logout')?.addEventListener('click', function() {
    localStorage.removeItem('loggedInUser '); // Remove username from local storage
    window.location.href = 'index.html'; // Redirect to login page
});